var story = {
 "docName": "experto",
 "docPath": "P_P_P",
 "docVersion": "V_V_V",
 "ownerName": "",
 "ownerEmail": "",
 "authorName": "V_V_N",
 "authorEmail": "V_V_E",
 "fontSizeFormat": -1,
 "fileType": "png",
 "disableInteractions": false,
 "highlightHotspot": true,
 "highlightAllHotspots": true,
 "hideGallery": false,
 "zoomEnabled": true,
 "title": "Demo",
 "layersExist": true,
 "pages": [
  {
   "id": "8:248",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Icons",
   "image": "icons.png",
   "imageFull": "icons.png",
   "index": 0,
   "width": 1228,
   "height": 3360,
   "x": -7939,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "8:2940",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Button",
   "image": "button.png",
   "imageFull": "button.png",
   "index": 1,
   "width": 465,
   "height": 2768,
   "x": -6588,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "4:5898",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Color",
   "image": "color.png",
   "imageFull": "color.png",
   "index": 2,
   "width": 979,
   "height": 915,
   "x": -5988,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "143:3121",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Component",
   "image": "component.png",
   "imageFull": "component.png",
   "index": 3,
   "width": 1152,
   "height": 1725,
   "x": -5268,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [],
   "links": [],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "26:1333",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Splash Screen",
   "image": "splash-screen.png",
   "imageFull": "splash-screen.png",
   "index": 4,
   "width": 390,
   "height": 844,
   "x": -2449,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "rect": {
      "x": 0,
      "y": 0,
      "width": 390,
      "height": 844
     },
     "index": 0,
     "page": 5,
     "disableAutoScroll": true
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "238:2258",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Login",
   "image": "login.png",
   "imageFull": "login.png",
   "index": 5,
   "width": 390,
   "height": 844,
   "x": -2009,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "rect": {
      "x": 21,
      "y": 551,
      "width": 348,
      "height": 55
     },
     "index": 1,
     "page": 6
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "8:2542",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Home page",
   "image": "home-page.png",
   "imageFull": "full/home-page.png",
   "index": 6,
   "width": 390,
   "height": 844,
   "x": -1569,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [
    {
     "constrains": {
      "top": false,
      "bottom": false,
      "left": false,
      "right": false,
      "height": false,
      "width": false
     },
     "x": 0,
     "y": 780,
     "width": 390,
     "height": 64,
     "type": "float",
     "index": 0,
     "isFloat": true,
     "isVertScroll": false,
     "links": [
      {
       "rect": {
        "x": 67,
        "y": 17,
        "width": 30,
        "height": 30
       },
       "index": 2,
       "page": 6
      },
      {
       "rect": {
        "x": 147,
        "y": 17,
        "width": 30,
        "height": 30
       },
       "index": 3,
       "page": 7
      }
     ],
     "image": "home-page-0.png",
     "mskH": 64
    }
   ],
   "links": [],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "13:4815",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Order",
   "image": "order.png",
   "imageFull": "full/order.png",
   "index": 7,
   "width": 390,
   "height": 844,
   "x": -1144,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [
    {
     "constrains": {
      "top": false,
      "bottom": false,
      "left": false,
      "right": false,
      "height": false,
      "width": false
     },
     "x": -9,
     "y": 782,
     "width": 390,
     "height": 64,
     "type": "float",
     "index": 0,
     "isFloat": true,
     "isVertScroll": false,
     "links": [
      {
       "rect": {
        "x": 295.1436767578125,
        "y": 4.57421875,
        "width": 71,
        "height": 30
       },
       "index": 5,
       "page": 8
      },
      {
       "rect": {
        "x": 67,
        "y": 17,
        "width": 30,
        "height": 30
       },
       "index": 12,
       "page": 6
      },
      {
       "rect": {
        "x": 147,
        "y": 17,
        "width": 30,
        "height": 30
       },
       "index": 13,
       "page": 7
      }
     ],
     "image": "order-0.png",
     "mskH": 64
    }
   ],
   "links": [
    {
     "rect": {
      "x": 17,
      "y": 730.4306640625,
      "width": 86.14366912841797,
      "height": 86.14366912841797
     },
     "index": 4,
     "page": 4
    },
    {
     "rect": {
      "x": 17,
      "y": 510,
      "width": 86.14366912841797,
      "height": 86.14366912841797
     },
     "index": 6,
     "page": 4
    },
    {
     "rect": {
      "x": 286.1436767578125,
      "y": 566.1435546875,
      "width": 71,
      "height": 30
     },
     "index": 7,
     "page": 8
    },
    {
     "rect": {
      "x": 17,
      "y": 412,
      "width": 86.14366912841797,
      "height": 86.14366912841797
     },
     "index": 8,
     "page": 4
    },
    {
     "rect": {
      "x": 286.1436767578125,
      "y": 468.1435546875,
      "width": 71,
      "height": 30
     },
     "index": 9,
     "page": 8
    },
    {
     "rect": {
      "x": 17,
      "y": 624.287109375,
      "width": 86.14366912841797,
      "height": 86.14366912841797
     },
     "index": 10,
     "page": 4
    },
    {
     "rect": {
      "x": 286.1436767578125,
      "y": 680.4306640625,
      "width": 71,
      "height": 30
     },
     "index": 11,
     "page": 8
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "143:690",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Order/Select",
   "image": "order-select.png",
   "imageFull": "full/order-select.png",
   "index": 8,
   "width": 390,
   "height": 844,
   "x": -734,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [
    {
     "constrains": {
      "top": false,
      "bottom": false,
      "left": false,
      "right": false,
      "height": false,
      "width": false
     },
     "x": 0,
     "y": 780,
     "width": 390,
     "height": 64,
     "type": "float",
     "index": 0,
     "isFloat": true,
     "isVertScroll": false,
     "links": [
      {
       "rect": {
        "x": 293.1436767578125,
        "y": 25.57421875,
        "width": 71,
        "height": 30
       },
       "index": 15,
       "page": 8
      },
      {
       "rect": {
        "x": 67,
        "y": 17,
        "width": 30,
        "height": 30
       },
       "index": 22,
       "page": 6
      },
      {
       "rect": {
        "x": 147,
        "y": 17,
        "width": 30,
        "height": 30
       },
       "index": 23,
       "page": 7
      }
     ],
     "image": "order-select-0.png",
     "mskH": 64
    }
   ],
   "links": [
    {
     "rect": {
      "x": 24,
      "y": 749.4306640625,
      "width": 86.14366912841797,
      "height": 86.14366912841797
     },
     "index": 14,
     "page": 4
    },
    {
     "rect": {
      "x": 24,
      "y": 537.1435546875,
      "width": 86.14366912841797,
      "height": 86.14366912841797
     },
     "index": 16,
     "page": 4
    },
    {
     "rect": {
      "x": 293.1436767578125,
      "y": 593.287109375,
      "width": 71,
      "height": 30
     },
     "index": 17,
     "page": 8
    },
    {
     "rect": {
      "x": 24,
      "y": 643.287109375,
      "width": 86.14366912841797,
      "height": 86.14366912841797
     },
     "index": 18,
     "page": 4
    },
    {
     "rect": {
      "x": 293.1436767578125,
      "y": 699.4306640625,
      "width": 71,
      "height": 30
     },
     "index": 19,
     "page": 8
    },
    {
     "rect": {
      "x": 24,
      "y": 431,
      "width": 86.14366912841797,
      "height": 86.14366912841797
     },
     "index": 20,
     "page": 10
    },
    {
     "rect": {
      "x": 346.1436767578125,
      "y": 493,
      "width": 18,
      "height": 18
     },
     "index": 21,
     "page": 9
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "13:5696",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Order/Detail",
   "image": "order-detail.png",
   "imageFull": "full/order-detail.png",
   "index": 9,
   "width": 390,
   "height": 844,
   "x": -294,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [
    {
     "constrains": {
      "top": false,
      "bottom": false,
      "left": false,
      "right": false,
      "height": false,
      "width": false
     },
     "x": 18,
     "y": 779,
     "width": 353,
     "height": 55,
     "type": "float",
     "index": 0,
     "isFloat": true,
     "isVertScroll": false,
     "links": [
      {
       "rect": {
        "x": 0,
        "y": 0,
        "width": 353,
        "height": 55
       },
       "index": 26,
       "page": 11
      }
     ],
     "image": "order-detail-0.png",
     "mskH": 55
    },
    {
     "constrains": {
      "top": false,
      "bottom": false,
      "left": false,
      "right": false,
      "height": false,
      "width": false
     },
     "x": -11,
     "y": 772,
     "width": 411,
     "height": 72.00000762939453,
     "type": "float",
     "index": 1,
     "isFloat": true,
     "isVertScroll": false,
     "links": [],
     "image": "order-detail-1.png",
     "mskH": 72.00000762939453,
     "shadow": "0px 3px 12px #0000000a"
    }
   ],
   "links": [
    {
     "rect": {
      "x": 24,
      "y": 381,
      "width": 86.14366912841797,
      "height": 86.14366912841797
     },
     "index": 24,
     "page": 10
    },
    {
     "rect": {
      "x": 346.1436767578125,
      "y": 443,
      "width": 18,
      "height": 18
     },
     "index": 25,
     "page": 9
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "26:883",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Menu/Detail",
   "image": "menu-detail.png",
   "imageFull": "full/menu-detail.png",
   "index": 10,
   "width": 390,
   "height": 844,
   "x": 146,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [
    {
     "constrains": {
      "top": false,
      "bottom": false,
      "left": false,
      "right": false,
      "height": false,
      "width": false
     },
     "x": 18,
     "y": 762,
     "width": 348,
     "height": 55,
     "type": "float",
     "index": 0,
     "isFloat": true,
     "isVertScroll": false,
     "links": [
      {
       "rect": {
        "x": 0,
        "y": 0,
        "width": 348,
        "height": 55
       },
       "index": 28,
       "page": 9
      }
     ],
     "image": "menu-detail-0.png",
     "mskH": 55
    }
   ],
   "links": [
    {
     "rect": {
      "x": 83,
      "y": 156,
      "width": 232,
      "height": 232
     },
     "index": 27,
     "page": 10
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "13:5988",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Order/Completed ",
   "image": "order-completed-.png",
   "imageFull": "full/order-completed-.png",
   "index": 11,
   "width": 390,
   "height": 844,
   "x": 586,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [
    {
     "constrains": {
      "top": false,
      "bottom": false,
      "left": false,
      "right": false,
      "height": false,
      "width": false
     },
     "x": 18,
     "y": 779,
     "width": 348,
     "height": 55,
     "type": "float",
     "index": 0,
     "isFloat": true,
     "isVertScroll": false,
     "links": [
      {
       "rect": {
        "x": 0,
        "y": 0,
        "width": 348,
        "height": 55
       },
       "index": 30,
       "page": 12
      }
     ],
     "image": "order-completed--0.png",
     "mskH": 55
    },
    {
     "constrains": {
      "top": false,
      "bottom": false,
      "left": false,
      "right": false,
      "height": false,
      "width": false
     },
     "x": -11,
     "y": 772,
     "width": 411,
     "height": 72.00000762939453,
     "type": "float",
     "index": 1,
     "isFloat": true,
     "isVertScroll": false,
     "links": [],
     "image": "order-completed--1.png",
     "mskH": 72.00000762939453,
     "shadow": "0px 3px 12px #0000000a"
    }
   ],
   "links": [
    {
     "rect": {
      "x": 35,
      "y": 461.57177734375,
      "width": 59,
      "height": 59
     },
     "index": 29,
     "page": 10
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  },
  {
   "id": "13:6638",
   "groupID": "13:6637",
   "transAnimType": 0,
   "title": "Home/ OrderStatus",
   "image": "home-orderstatus.png",
   "imageFull": "full/home-orderstatus.png",
   "index": 12,
   "width": 390,
   "height": 844,
   "x": 1026,
   "y": -7305,
   "type": "regular",
   "fixedPanels": [
    {
     "constrains": {
      "top": false,
      "bottom": false,
      "left": false,
      "right": false,
      "height": false,
      "width": false
     },
     "x": 0,
     "y": 780,
     "width": 390,
     "height": 64,
     "type": "float",
     "index": 0,
     "isFloat": true,
     "isVertScroll": false,
     "links": [
      {
       "rect": {
        "x": 67,
        "y": 17,
        "width": 30,
        "height": 30
       },
       "index": 32,
       "page": 6
      },
      {
       "rect": {
        "x": 147,
        "y": 17,
        "width": 30,
        "height": 30
       },
       "index": 33,
       "page": 7
      }
     ],
     "image": "home-orderstatus-0.png",
     "mskH": 64
    }
   ],
   "links": [
    {
     "rect": {
      "x": 24,
      "y": 512,
      "width": 49,
      "height": 49
     },
     "index": 31,
     "page": 10
    }
   ],
   "overlayPinPage": 6,
   "overlayOutsideClickIgnore": true,
   "layout": null
  }
 ],
 "groups": [
  {
   "id": "13:6637",
   "name": "Starbucks UI"
  }
 ],
 "startPageIndex": 4,
 "totalImages": 13,
 "backColor": "#FFFFFF"
}